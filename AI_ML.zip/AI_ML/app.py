import heapq

locations = [
    "main gate", "auditorium", "cafe", "library", "acad-b", "faculty hostel",
    "food court", "laundry", "gym", "hostel-1", "mart", "temple", "sports complex"
]

campus_graph = {
    "main gate": {"cafe": 124.5, "auditorium": 92, "library": 107, "acad-b": 209, "food court": 389, "laundry": 396, "faculty hostel": 377, "gym": 439, "hostel-1": 663, "mart": 723, "sports complex": 1170, "temple": 410},
    "cafe": {"main gate": 124.5, "auditorium": 10, "library": 66, "acad-b": 147.5, "food court": 327.5, "laundry": 334.5, "faculty hostel": 315.5, "gym": 377.5, "hostel-1": 601.5, "mart": 661.5, "sports complex": 1108.5, "temple": 534.5},
    "auditorium": {"main gate": 92, "cafe": 10, "library": 10, "acad-b": 117, "food court": 297, "laundry": 304, "faculty hostel": 285, "gym": 347, "hostel-1": 569, "mart": 629, "sports complex": 1076, "temple": 318},
    "library": {"main gate": 107, "cafe": 66, "auditorium": 10, "acad-b": 163, "food court": 343, "laundry": 350, "faculty hostel": 331, "gym": 393, "hostel-1": 615, "mart": 675, "sports complex": 1122, "temple": 364},
    "acad-b": {"main gate": 209, "cafe": 147.5, "auditorium": 117, "library": 163, "food court": 180, "laundry": 187, "faculty hostel": 168, "gym": 230, "hostel-1": 452, "mart": 512, "sports complex": 959, "temple": 201},
    "faculty hostel": {"main gate": 377, "cafe": 315.5, "auditorium": 285, "library": 331, "acad-b": 168, "food court": 193.5, "laundry": 86, "gym": 243.5, "hostel-1": 286, "mart": 346, "sports complex": 743, "temple": 33},
    "food court": {"main gate": 389, "cafe": 327.5, "auditorium": 297, "library": 343, "acad-b": 180, "laundry": 107.5, "faculty hostel": 193.5, "gym": 50, "hostel-1": 247, "mart": 307, "sports complex": 754, "temple": 226.5},
    "laundry": {"main gate": 396, "cafe": 334.5, "auditorium": 304, "library": 350, "acad-b": 187, "food court": 107.5, "faculty hostel": 86, "gym": 157.5, "hostel-1": 265, "mart": 325, "sports complex": 772, "temple": 119},
    "gym": {"main gate": 439, "cafe": 377.5, "auditorium": 347, "library": 393, "acad-b": 230, "food court": 50, "laundry": 157.5, "faculty hostel": 243.5, "hostel-1": 297, "mart": 357, "sports complex": 80, "temple": 276.5},
    "hostel-1": {"main gate": 663, "cafe": 601.5, "auditorium": 569, "library": 615, "acad-b": 452, "food court": 247, "laundry": 265, "faculty hostel": 286, "gym": 297, "mart": 60, "sports complex": 507, "temple": 225},
    "mart": {"main gate": 723, "cafe": 661.5, "auditorium": 629, "library": 675, "acad-b": 512, "laundry": 325, "faculty hostel": 346, "hostel-1": 60, "food court": 307, "gym": 357, "sports complex": 557, "temple": 275},
    "sports complex": {"main gate": 1170, "cafe": 1108.5, "auditorium": 1076, "library": 1122, "acad-b": 959, "food court": 754, "laundry": 772, "faculty hostel": 793, "gym": 80, "hostel-1": 507, "mart": 557, "temple": 732},
    "temple": {"main gate": 410, "cafe": 534.5, "auditorium": 318, "library": 364, "acad-b": 201, "food court": 226.5, "laundry": 119, "faculty hostel": 33, "gym": 276.5, "hostel-1": 225, "mart": 275, "sports complex": 732},
}

location_info = {
    "main gate": {"facilities": "Entry", "time": "9AM-5PM"},
    "auditorium": {"facilities": "Events, talks, ceremony", "time": "Open during events"},
    "library": {"facilities": "Study halls, discussion rooms", "time": "8:30AM-10PM"},
    "cafe": {"facilities": "Food and snacks", "time": "8AM-6:30PM"},
    "acad-b": {"facilities": "Engineering classrooms, labs", "time": "8:30AM-6:30PM"},
    "faculty hostel": {"facilities": "Accommodation", "time": "24 Hours"},
    "food court": {"facilities": "Meals", "time": "Meal slots 7:30-9:30, 12:30-2:30, 4:30-6:00, 7:30-9:30"},
    "laundry": {"facilities": "Clothes wash", "time": "Scheduled: Girls-Tue/Sat, Boys-Mon/Fri"},
    "gym": {"facilities": "Workout", "time": "Student slots"},
    "hostel-1": {"facilities": "Accommodation", "time": "24 Hours"},
    "mart": {"facilities": "Snacks, stationery", "time": "10AM-1PM, 2:30PM-10PM"},
    "temple": {"facilities": "Puja", "time": "Occasions"},
    "sports complex": {"facilities": "Play area", "time": "Morning, Evening"},
}

WALK_SPEED_MPS = 1.25

def estimate_time(distance):
    return round(distance / WALK_SPEED_MPS / 60, 2)

def bfs(start, goal):
    from collections import deque
    queue = deque([(start, [start], 0)])
    visited = set()
    while queue:
        current, path, dist = queue.popleft()
        if current == goal:
            return path, dist
        visited.add(current)
        for neighbor in campus_graph[current]:
            if neighbor not in visited and neighbor not in (node for node, _, _ in queue):
                queue.append((neighbor, path + [neighbor], dist + campus_graph[current][neighbor]))
    return None, None

def dfs(start, goal, visited=None, path=None, dist=0):
    if visited is None:
        visited = set()
    if path is None:
        path = [start]
    visited.add(start)
    if start == goal:
        return path, dist
    for neighbor in campus_graph[start]:
        if neighbor not in visited:
            res = dfs(neighbor, goal, visited, path + [neighbor], dist + campus_graph[start][neighbor])
            if res:
                return res
    return None, None

def ucs(start, goal):
    heap = [(0, start, [start])]
    visited = {}
    while heap:
        cost, node, path = heapq.heappop(heap)
        if node == goal:
            return path, cost
        if node in visited and visited[node] <= cost:
            continue
        visited[node] = cost
        for neighbor, c in campus_graph[node].items():
            heapq.heappush(heap, (cost + c, neighbor, path + [neighbor]))
    return None, None

def heuristic(node, goal):
    return campus_graph[node].get(goal, 0)

def astar(start, goal):
    heap = [(0 + heuristic(start, goal), 0, start, [start])]
    visited = {}
    while heap:
        f, g, node, path = heapq.heappop(heap)
        if node == goal:
            return path, g
        if node in visited and visited[node] <= g:
            continue
        visited[node] = g
        for neighbor, cost in campus_graph[node].items():
            g_new = g + cost
            f_new = g_new + heuristic(neighbor, goal)
            heapq.heappush(heap, (f_new, g_new, neighbor, path + [neighbor]))
    return None, None

def recommend_algorithm(distance_bfs, distance_dfs, distance_ucs, distance_astar):
    distances = {
        "BFS": distance_bfs,
        "DFS": distance_dfs,
        "UCS": distance_ucs,
        "A*": distance_astar
    }
    valid = {k: v for k, v in distances.items() if v is not None}
    best_algo = min(valid, key=valid.get)
    return best_algo

def show_location_info(loc):
    if loc not in locations:
        print("Location not found.")
        return
    info = location_info.get(loc)
    if info:
        print(f"\nInformation for {loc.title()}:")
        print(f"Facilities: {info['facilities']}")
        print(f"Opening Hours: {info['time']}\n")
    else:
        print("No information available for this location.\n")

def main():
    print("Welcome to Campus Path Finder!")
    print("Type 'info' to get location details.")
    print("Type 'path' to find the best path between two locations.")
    print("Type 'exit' to quit.\n")
    
    print("Available locations:")
    for loc in locations:
        print(f" - {loc}")
    
    while True:
        command = input("\nEnter command (info/path/exit): ").strip().lower()
        
        if command == "exit":
            print("Goodbye!")
            break
        
        elif command == "info":
            loc = input("Enter location name: ").strip().lower()
            show_location_info(loc)
        
        elif command == "path":
            start = input("Enter start location: ").strip().lower()
            goal = input("Enter goal location: ").strip().lower()

            if start not in campus_graph or goal not in campus_graph:
                print("Invalid start or goal location. Please try again.")
                continue
            
            path_bfs, dist_bfs = bfs(start, goal)
            path_dfs, dist_dfs = dfs(start, goal)
            path_ucs, dist_ucs = ucs(start, goal)
            path_astar, dist_astar = astar(start, goal)
            best_algo = recommend_algorithm(dist_bfs, dist_dfs, dist_ucs, dist_astar)

            print(f"\nBFS path: {path_bfs}\nDistance: {dist_bfs} meters\nEstimated time: {estimate_time(dist_bfs)} minutes\n")
            print(f"DFS path: {path_dfs}\nDistance: {dist_dfs} meters\nEstimated time: {estimate_time(dist_dfs)} minutes\n")
            print(f"UCS path: {path_ucs}\nDistance: {dist_ucs} meters\nEstimated time: {estimate_time(dist_ucs)} minutes\n")
            print(f"A* path: {path_astar}\nDistance: {dist_astar} meters\nEstimated time: {estimate_time(dist_astar)} minutes\n")

            print(f"Recommended algorithm: {best_algo}")
            if best_algo == "BFS":
                best_path, best_dist = path_bfs, dist_bfs
            elif best_algo == "DFS":
                best_path, best_dist = path_dfs, dist_dfs
            elif best_algo == "UCS":
                best_path, best_dist = path_ucs, dist_ucs
            else:
                best_path, best_dist = path_astar, dist_astar

            print(f"\nBest path: {best_path}")
            print(f"Distance: {best_dist} meters")
            print(f"Estimated walking time: {estimate_time(best_dist)} minutes\n")
        
        else:
            print("Unknown command. Please enter 'info', 'path', or 'exit'.")

if __name__ == "__main__":
    main()
