import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, accuracy_score
import warnings

# Suppress minor warnings for cleaner notebook output
warnings.filterwarnings('ignore', category=FutureWarning)
warnings.filterwarnings('ignore', category=UserWarning)

# 1. Load Cleaned Data 
try:
    df = pd.read_csv('combined_fifa_cleaned1.csv')
    print(" Cleaned dataset loaded successfully.")
except FileNotFoundError as e:
    print(f" Error loading file: {e}. Please ensure 'combined_fifa_cleaned.csv' is available.")
    raise

# 2. Data Preparation: Preprocessing and Splitting 
print("           DATA PREPROCESSING AND SPLITTING             ")

# Define Target and Features (Feature Selection)
# The target variable is the numerical match result: 1=Win, 0=Draw, -1=Lose.
TARGET_COLUMN = 'home_team_result_num'

# **Feature Selection:** Using the most predictive features engineered from Task 1.
FEATURE_COLUMNS = [
    'rank_difference',
    'point_difference',
    'strength_index_difference',
    'rolling_win_rate_difference',
    'home_is_world_cup_winner',
    'neutral_location',
]

# Remove rows where engineered features are NaN (usually from very old matches lacking FIFA point data)
df_model = df.dropna(subset=FEATURE_COLUMNS).copy()

X = df_model[FEATURE_COLUMNS]
y = df_model[TARGET_COLUMN]

print(f"Total instances used for modeling: {len(X)}")

# Preprocessing Steps: Scaling
# Scaling: StandardScaler is used on the continuous 'difference' features to standardize them
# (mean=0, variance=1).
scaler = StandardScaler()
X_scaled = X.copy()

# Identify continuous features to be scaled
features_to_scale = [col for col in FEATURE_COLUMNS if col not in ['home_is_world_cup_winner', 'neutral_location']]

X_scaled[features_to_scale] = scaler.fit_transform(X_scaled[features_to_scale])

print("\nFeatures scaled using StandardScaler:")
print(X_scaled.head())

# Train-Test Split (Ensuring Fair Evaluation)
# Split data into training (80%) and testing (20%) sets.
X_train, X_test, y_train, y_test = train_test_split(
    X_scaled, y, test_size=0.20, random_state=42, stratify=y
)

print(f"\nTraining set size: {len(X_train)}")
print(f"Testing set size: {len(X_test)}")


# 3. Model Implementation and Training 
print("           MODEL IMPLEMENTATION AND TRAINING            ")


# Hyperparameter Tuning Approach Description:
# Class Imbalance: Both models use `class_weight='balanced'` to handle class imbalance.

# Model 1: Logistic Regression
print("\n Model 1: Logistic Regression (Classification)")

log_reg_model = LogisticRegression(
    multi_class='multinomial', 
    solver='lbfgs',
    max_iter=1000,
    class_weight='balanced',
    random_state=42,
    # FIX APPLIED: Set n_jobs=1 to avoid multiprocessing error
    n_jobs=1 
)

# Training the model
log_reg_model.fit(X_train, y_train)
print("Logistic Regression Model Trained Successfully.")

# Initial Evaluation
y_pred_lr = log_reg_model.predict(X_test)
print(f"Test Accuracy: {accuracy_score(y_test, y_pred_lr):.4f}")


# Model 2: Random Forest Classifier
print("\n Model 2: Random Forest Classifier")

rf_model = RandomForestClassifier(
    n_estimators=200, 
    max_depth=10, 
    min_samples_leaf=5, 
    class_weight='balanced',
    random_state=42,
    # FIX APPLIED: Set n_jobs=1 to avoid multiprocessing error
    n_jobs=1 # Although less likely to crash here, it's good practice for consistency
)

# Training the model
rf_model.fit(X_train, y_train)
print("Random Forest Classifier Model Trained Successfully.")

# Initial Evaluation 
y_pred_rf = rf_model.predict(X_test)
print(f"Test Accuracy: {accuracy_score(y_test, y_pred_rf):.4f}")


# 4. Cross-Validation Check
# Demonstrating the use of k-fold cross-validation for a fairer evaluation
print("\n 5-Fold Cross-Validation Check (Logistic Regression) ")

# FIX APPLIED: Set n_jobs=1 to avoid multiprocessing error
cv_scores = cross_val_score(log_reg_model, X_scaled, y, cv=5, scoring='accuracy', n_jobs=1)

print(f"CV Scores (5 Folds): {cv_scores}")
print(f"Mean CV Accuracy: {cv_scores.mean():.4f}")