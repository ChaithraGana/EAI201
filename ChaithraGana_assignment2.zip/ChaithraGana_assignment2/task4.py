import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler, label_binarize
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    roc_curve,
    auc,
    roc_auc_score
)
import warnings

# --- Setup and Data Loading (Task 1 & 2 Start) ---
warnings.filterwarnings('ignore', category=FutureWarning)
warnings.filterwarnings('ignore', category=UserWarning)
sns.set_style("whitegrid")

# Define constants
TARGET_COLUMN = 'home_team_result_num'
FEATURE_COLUMNS = [
    'rank_difference', 'point_difference', 'strength_index_difference',
    'rolling_win_rate_difference', 'home_is_world_cup_winner', 'neutral_location',
]
CLASS_NAMES = ['Loss (-1)', 'Draw (0)', 'Win (1)']
CLASSES = [-1, 0, 1]


try:
    df = pd.read_csv('combined_fifa_cleaned1.csv')
    print("✅ Cleaned dataset loaded successfully.")
except FileNotFoundError as e:
    print(f"❌ Error loading file: {e}. Please ensure 'combined_fifa_cleaned1.csv' is available.")
    raise

# --- Data Preparation and Training (Task 2 Continuation) ---
print("\n" + "="*80)
print("            DATA PREPROCESSING AND MODEL TRAINING (Tasks 2 & 3 Setup)            ")
print("="*80)

df_model = df.dropna(subset=FEATURE_COLUMNS).copy()
X = df_model[FEATURE_COLUMNS]
y = df_model[TARGET_COLUMN]

# Scaling
scaler = StandardScaler()
X_scaled = X.copy()
features_to_scale = [col for col in FEATURE_COLUMNS if col not in ['home_is_world_cup_winner', 'neutral_location']]
X_scaled[features_to_scale] = scaler.fit_transform(X_scaled[features_to_scale])

# Split
X_train, X_test, y_train, y_test = train_test_split(
    X_scaled, y, test_size=0.20, random_state=42, stratify=y
)

# Training Logistic Regression (FIXED: n_jobs=1)
print("\n--- Training Logistic Regression (n_jobs=1) ---")
log_reg_model = LogisticRegression(
    multi_class='multinomial', solver='lbfgs', max_iter=1000,
    class_weight='balanced', random_state=42, n_jobs=1 
)
log_reg_model.fit(X_train, y_train)
print("Logistic Regression Model Trained Successfully.")


# Training Random Forest Classifier (FIXED: n_jobs=1)
print("\n--- Training Random Forest Classifier (n_jobs=1) ---")
rf_model = RandomForestClassifier(
    n_estimators=200, max_depth=10, min_samples_leaf=5,
    class_weight='balanced', random_state=42, n_jobs=1
)
rf_model.fit(X_train, y_train)
print("Random Forest Classifier Model Trained Successfully.")


# =========================================================================
# 📢 TASK 4: FEATURE IMPORTANCE AND INTERPRETATION
# =========================================================================

print("\n" + "="*80)
print("            TASK 4: FEATURE IMPORTANCE AND INTERPRETATION ANALYSIS            ")
print("="*80)

# --- 4.1. Logistic Regression: Coefficient Analysis ---
print("\n🌟 Logistic Regression: Feature Coefficients (Impact on Log-Odds)")
print("-" * 60)

# Extract and order coefficients based on our desired class order [-1, 0, 1]
coefs = log_reg_model.coef_
model_classes = log_reg_model.classes_

# Create a mapping from our desired class order to the model's internal index
class_to_index = {cls: np.where(model_classes == cls)[0][0] for cls in CLASSES}
coefs_ordered = np.array([coefs[class_to_index[cls], :] for cls in CLASSES])

# Create DataFrame for clean display and ranking
coef_df = pd.DataFrame(coefs_ordered.T, index=FEATURE_COLUMNS, columns=CLASS_NAMES)
coef_df['Max_Absolute_Coeff'] = coef_df.abs().max(axis=1)
coef_df_ranked = coef_df.sort_values(by='Max_Absolute_Coeff', ascending=False)

print("Ranked Coefficients (sorted by maximum absolute magnitude):")
print(coef_df_ranked)

# Visualization of LR Coefficients (Heatmap) 
plt.figure(figsize=(12, 7))
sns.heatmap(
    coef_df_ranked.drop(columns=['Max_Absolute_Coeff']), # Drop the ranking column for clean plot
    annot=True,
    fmt=".3f",
    cmap='vlag',
    center=0,
    linewidths=.5,
    linecolor='black',
    cbar_kws={'label': 'Coefficient Value'}
)
plt.title('Logistic Regression: Feature Coefficients by Outcome Class', fontsize=16)
plt.ylabel('Feature', fontsize=12)
plt.xticks(rotation=45, ha='right')
plt.tight_layout()
plt.savefig('lr_coefficients_heatmap_task4.png')
plt.close()
print("Saved LR Coefficient Heatmap: lr_coefficients_heatmap_task4.png")


# --- 4.2. Random Forest: Feature Importance (Gini Importance) ---
print("\n\n🌲 Random Forest Classifier: Feature Importance (Gini Importance)")
print("-" * 60)

# Extract Gini importance scores
rf_importance = rf_model.feature_importances_

# Create DataFrame for clean display and ranking
rf_importance_df = pd.DataFrame({
    'Feature': FEATURE_COLUMNS,
    'Importance': rf_importance
}).sort_values(by='Importance', ascending=False).reset_index(drop=True)

print("Ranked Random Forest Importance:")
print(rf_importance_df)

# Visualization of RF Feature Importance (Bar Plot) 
plt.figure(figsize=(10, 6))
sns.barplot(
    x='Importance',
    y='Feature',
    data=rf_importance_df,
    palette='viridis'
)
plt.title('Random Forest: Feature Importance Ranking', fontsize=16)
plt.xlabel('Gini Importance Score', fontsize=12)
plt.ylabel('Feature', fontsize=12)
plt.tight_layout()
plt.savefig('rf_feature_importance_task4.png')
plt.close()
print("Saved RF Feature Importance Plot: rf_feature_importance_task4.png")

