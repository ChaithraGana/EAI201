import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, label_binarize
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    roc_curve,
    auc,
    roc_auc_score
)
import warnings

# --- Setup and Data Loading (Task 1 & 2 Start) ---
warnings.filterwarnings('ignore', category=FutureWarning)
warnings.filterwarnings('ignore', category=UserWarning)
sns.set_style("whitegrid")

# NOTE: Ensure 'combined_fifa_cleaned1.csv' is in your current working directory
try:
    df = pd.read_csv('combined_fifa_cleaned1.csv')
    print("✅ Cleaned dataset loaded successfully.")
except FileNotFoundError as e:
    print(f"❌ Error loading file: {e}. Please ensure 'combined_fifa_cleaned1.csv' is available.")
    raise

# --- Data Preparation and Training (Task 2 Continuation) ---

TARGET_COLUMN = 'home_team_result_num'
FEATURE_COLUMNS = [
    'rank_difference', 'point_difference', 'strength_index_difference',
    'rolling_win_rate_difference', 'home_is_world_cup_winner', 'neutral_location',
]
# Define classes for plotting and reporting
CLASS_NAMES = ['Loss (-1)', 'Draw (0)', 'Win (1)']
CLASSES = [-1, 0, 1]

df_model = df.dropna(subset=FEATURE_COLUMNS).copy()
X = df_model[FEATURE_COLUMNS]
y = df_model[TARGET_COLUMN]

# Scaling
scaler = StandardScaler()
X_scaled = X.copy()
features_to_scale = [col for col in FEATURE_COLUMNS if col not in ['home_is_world_cup_winner', 'neutral_location']]
X_scaled[features_to_scale] = scaler.fit_transform(X_scaled[features_to_scale])

# Split
X_train, X_test, y_train, y_test = train_test_split(
    X_scaled, y, test_size=0.20, random_state=42, stratify=y
)
print(f"Total instances used for modeling: {len(X)}")
print(f"Training set size: {len(X_train)}")
print(f"Testing set size: {len(X_test)}")

# Training Logistic Regression (FIXED: n_jobs=1)
print("\n--- Training Logistic Regression (n_jobs=1) ---")
log_reg_model = LogisticRegression(
    multi_class='multinomial', solver='lbfgs', max_iter=1000,
    class_weight='balanced', random_state=42, n_jobs=1 # FIX APPLIED
)
log_reg_model.fit(X_train, y_train)
y_pred_lr = log_reg_model.predict(X_test)
y_proba_lr = log_reg_model.predict_proba(X_test)
print("Logistic Regression Model Trained Successfully.")


# Training Random Forest Classifier (FIXED: n_jobs=1)
print("\n--- Training Random Forest Classifier (n_jobs=1) ---")
rf_model = RandomForestClassifier(
    n_estimators=200, max_depth=10, min_samples_leaf=5,
    class_weight='balanced', random_state=42, n_jobs=1 # FIX APPLIED
)
rf_model.fit(X_train, y_train)
y_pred_rf = rf_model.predict(X_test)
y_proba_rf = rf_model.predict_proba(X_test)
print("Random Forest Classifier Model Trained Successfully.")


# --- 2. TASK 3: Evaluation and Visualization Functions ---

print("\n" + "="*80)
print("            TASK 3: MODEL EVALUATION & COMPARISON            ")
print("="*80)

# 2.1. Evaluation Metrics Function
def evaluate_model(y_test, y_pred, y_proba, model_name):
    """Calculates and prints classification metrics and ROC-AUC score."""
    print(f"\n--- {model_name} Performance Metrics ---")
    print(f"Accuracy: {accuracy_score(y_test, y_pred):.4f}")
    print("\nClassification Report (Precision, Recall, F1-score):")
    print(classification_report(y_test, y_pred, target_names=CLASS_NAMES, zero_division=0))

    # Calculate Macro-Averaged ROC-AUC (One-vs-Rest)
    # Check if probas are available and correct shape (3 classes)
    if y_proba is not None and y_proba.shape[1] == 3:
        y_test_bin = label_binarize(y_test, classes=CLASSES)
        roc_auc_macro = roc_auc_score(y_test_bin, y_proba, average='macro')
        print(f"Macro-Averaged ROC-AUC (OvR): {roc_auc_macro:.4f}")
    else:
        print("ROC-AUC not calculated or probability shape is incorrect.")


# 2.2. Confusion Matrix Plot Function
def plot_confusion_matrix(y_test, y_pred, model_name, filename):
    """Generates and saves a confusion matrix plot."""
    cm = confusion_matrix(y_test, y_pred, labels=CLASSES)
    plt.figure(figsize=(8, 6))
    sns.heatmap(
        cm, annot=True, fmt='d', cmap='Blues', linewidths=.5,
        xticklabels=CLASS_NAMES, yticklabels=CLASS_NAMES
    )
    plt.title(f'Confusion Matrix: {model_name}', fontsize=14)
    plt.ylabel('True Label', fontsize=12)
    plt.xlabel('Predicted Label', fontsize=12)
    plt.tight_layout()
    plt.savefig(filename)
    plt.close()
    print(f"Saved Confusion Matrix: {filename}")


# 2.3. ROC Curve Plot Function (OvR)
def plot_multiclass_roc(y_test, y_proba, model_name, filename):
    """Generates and saves a Multi-class OvR ROC Curve plot."""
    y_test_bin = label_binarize(y_test, classes=CLASSES)
    n_classes = y_test_bin.shape[1]
    fpr = dict()
    tpr = dict()
    roc_auc_scores = dict()

    for i in range(n_classes):
        # Calculate ROC curve for each class (One-vs-Rest)
        fpr[i], tpr[i], _ = roc_curve(y_test_bin[:, i], y_proba[:, i])
        roc_auc_scores[i] = auc(fpr[i], tpr[i])

    plt.figure(figsize=(10, 8))
    colors = ['blue', 'orange', 'green']
    for i, color in zip(range(n_classes), colors):
        plt.plot(
            fpr[i], tpr[i], color=color, lw=2,
            label=f'ROC curve for {CLASS_NAMES[i]} (AUC = {roc_auc_scores[i]:.2f})'
        )

    plt.plot([0, 1], [0, 1], 'k--', lw=2, label='Chance')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate (FPR)', fontsize=12)
    plt.ylabel('True Positive Rate (TPR)', fontsize=12)
    plt.title(f'Multi-class ROC Curve (One-vs-Rest): {model_name}', fontsize=14)
    plt.legend(loc="lower right", fontsize=10)
    plt.tight_layout()
    plt.savefig(filename)
    plt.close()
    print(f"Saved ROC Curve: {filename}")


# --- Execute Evaluation and Plotting ---

# Model 1: Logistic Regression
evaluate_model(y_test, y_pred_lr, y_proba_lr, "Logistic Regression")
plot_confusion_matrix(y_test, y_pred_lr, "Logistic Regression", "cm_logistic_regression.png")
plot_multiclass_roc(y_test, y_proba_lr, "Logistic Regression", "roc_logistic_regression.png")

# Model 2: Random Forest Classifier
evaluate_model(y_test, y_pred_rf, y_proba_rf, "Random Forest Classifier")
plot_confusion_matrix(y_test, y_pred_rf, "Random Forest Classifier", "cm_random_forest.png")
plot_multiclass_roc(y_test, y_proba_rf, "Random Forest Classifier", "roc_random_forest.png")