import pandas as pd
import numpy as np
import joblib
import random
from collections import defaultdict

# --- SIMULATED DATA (ADJUSTED FOR 48 TEAMS INCLUDING CONFIRMED 28) ---
# NOTE: This data is simulated and prioritized around the user's 28 confirmed teams.
# Canada has been added to this list and lower ranks have been adjusted to maintain 48 unique entries.
TEAM_2026_DATA = {
    # Top Tier (High Rank, High Strength)
    'Brazil': {'rank': 1, 'points': 1842, 'win_rate': 0.85, 'strength_index': 92.5},
    'Argentina': {'rank': 2, 'points': 1838, 'win_rate': 0.82, 'strength_index': 91.8},
    'England': {'rank': 3, 'points': 1830, 'win_rate': 0.78, 'strength_index': 90.5},
    
    # Remaining High-Ranked Teams (Predicted to Qualify)
    'France': {'rank': 4, 'points': 1799, 'win_rate': 0.80, 'strength_index': 91.2},
    'Belgium': {'rank': 5, 'points': 1798, 'win_rate': 0.75, 'strength_index': 89.5},
    'Portugal': {'rank': 6, 'points': 1785, 'win_rate': 0.70, 'strength_index': 88.0},
    'Netherlands': {'rank': 7, 'points': 1743, 'win_rate': 0.70, 'strength_index': 88.3},
    'Spain': {'rank': 8, 'points': 1727, 'win_rate': 0.65, 'strength_index': 87.0},
    'Italy': {'rank': 9, 'points': 1718, 'win_rate': 0.60, 'strength_index': 85.5},
    'Croatia': {'rank': 10, 'points': 1709, 'win_rate': 0.68, 'strength_index': 86.0},
    'Germany': {'rank': 11, 'points': 1675, 'win_rate': 0.62, 'strength_index': 84.9},
    
    # Confirmed Hosts & Strong CONMEBOL/CAF
    'USA': {'rank': 12, 'points': 1665, 'win_rate': 0.65, 'strength_index': 84.0},
    'Mexico': {'rank': 13, 'points': 1650, 'win_rate': 0.60, 'strength_index': 83.5},
    'Uruguay': {'rank': 14, 'points': 1630, 'win_rate': 0.58, 'strength_index': 82.2},
    'Colombia': {'rank': 15, 'points': 1625, 'win_rate': 0.55, 'strength_index': 81.5},
    'Morocco': {'rank': 16, 'points': 1620, 'win_rate': 0.65, 'strength_index': 82.5},
    'Japan': {'rank': 17, 'points': 1618, 'win_rate': 0.70, 'strength_index': 83.0},
    'Senegal': {'rank': 18, 'points': 1610, 'win_rate': 0.70, 'strength_index': 82.0},
    'Iran': {'rank': 19, 'points': 1595, 'win_rate': 0.60, 'strength_index': 81.0},
    'South Korea': {'rank': 20, 'points': 1588, 'win_rate': 0.62, 'strength_index': 80.5},
    
    # Remaining Predicted Qualifiers (UEFA/CONMEBOL/AFC)
    'Peru': {'rank': 21, 'points': 1584, 'win_rate': 0.50, 'strength_index': 79.5},
    'Sweden': {'rank': 22, 'points': 1580, 'win_rate': 0.55, 'strength_index': 78.8},
    'Austria': {'rank': 23, 'points': 1560, 'win_rate': 0.52, 'strength_index': 78.2},
    'Ukraine': {'rank': 24, 'points': 1555, 'win_rate': 0.50, 'strength_index': 77.5},
    'Chile': {'rank': 25, 'points': 1550, 'win_rate': 0.48, 'strength_index': 76.5},
    'Serbia': {'rank': 26, 'points': 1545, 'win_rate': 0.50, 'strength_index': 78.0},
    'Poland': {'rank': 27, 'points': 1533, 'win_rate': 0.45, 'strength_index': 77.0},
    'Switzerland': {'rank': 28, 'points': 1528, 'win_rate': 0.50, 'strength_index': 80.0},
    
    # Confirmed Mid-to-Low Ranked Teams
    'Ecuador': {'rank': 29, 'points': 1500, 'win_rate': 0.48, 'strength_index': 76.8},
    'Tunisia': {'rank': 30, 'points': 1490, 'win_rate': 0.55, 'strength_index': 78.5},
    'Egypt': {'rank': 31, 'points': 1488, 'win_rate': 0.60, 'strength_index': 78.0},
    'Algeria': {'rank': 32, 'points': 1480, 'win_rate': 0.55, 'strength_index': 77.0},
    'Ghana': {'rank': 33, 'points': 1470, 'win_rate': 0.45, 'strength_index': 73.5},
    'Saudi Arabia': {'rank': 34, 'points': 1460, 'win_rate': 0.50, 'strength_index': 75.0},
    'Australia': {'rank': 35, 'points': 1450, 'win_rate': 0.60, 'strength_index': 79.2},
    'Qatar': {'rank': 36, 'points': 1440, 'win_rate': 0.55, 'strength_index': 77.5},
    
    # CONCACAF Host (Missing in previous version, now added at Rank 37)
    'Canada': {'rank': 37, 'points': 1435, 'win_rate': 0.45, 'strength_index': 73.0},

    # Remaining Predicted Teams & Confirmed Teams (Ranks shifted down by 1)
    'Costa Rica': {'rank': 38, 'points': 1430, 'win_rate': 0.40, 'strength_index': 72.5}, # Predicted
    'Nigeria': {'rank': 39, 'points': 1420, 'win_rate': 0.55, 'strength_index': 76.0}, # Predicted
    'Cameroon': {'rank': 40, 'points': 1410, 'win_rate': 0.50, 'strength_index': 75.2}, # Predicted
    'Paraguay': {'rank': 41, 'points': 1400, 'win_rate': 0.40, 'strength_index': 75.5}, # Confirmed
    'Uzbekistan': {'rank': 42, 'points': 1395, 'win_rate': 0.45, 'strength_index': 74.2}, # Confirmed
    'Jordan': {'rank': 43, 'points': 1390, 'win_rate': 0.40, 'strength_index': 72.0}, # Confirmed
    'Ivory Coast': {'rank': 44, 'points': 1385, 'win_rate': 0.50, 'strength_index': 76.8}, # Confirmed
    'South Africa': {'rank': 45, 'points': 1380, 'win_rate': 0.40, 'strength_index': 71.0}, # Confirmed
    'Cape Verde': {'rank': 46, 'points': 1375, 'win_rate': 0.35, 'strength_index': 70.8}, # Confirmed
    'Norway': {'rank': 47, 'points': 1370, 'win_rate': 0.48, 'strength_index': 74.5}, # Predicted (Lowest ranked)
    'New Zealand': {'rank': 48, 'points': 1360, 'win_rate': 0.30, 'strength_index': 68.5}, # Confirmed
}
# Placeholder check/removal code remains for safety, though unnecessary now
TEAM_2026_DATA.pop('South Africa_C', None) 


# Teams confirmed by the user (28 teams) - Mapped to code names
CONFIRMED_28 = [
    'USA', 'Mexico', 'Canada', 
    'Japan', 'Iran', 'Australia', 'South Korea', 'Uzbekistan', 'Jordan', 'Qatar', 'Saudi Arabia',
    'Morocco', 'Tunisia', 'Egypt', 'Algeria', 'Cape Verde', 'Ghana', 'Ivory Coast', 'Senegal', 'South Africa',
    'Argentina', 'Brazil', 'Ecuador', 'Uruguay', 'Colombia', 'Paraguay',
    'New Zealand', 'England'
]

# --- 1. SETUP AND UTILITY FUNCTIONS ---

print("--- 1. Loading Model and Configuration ---")

try:
    # Load the best model, scaler, and feature list (assuming these files exist from previous tasks)
    MODEL = joblib.load('final_fifa_prediction_model.pkl')
    SCALER = joblib.load('scaler_for_prediction.pkl')
    FEATURE_COLUMNS = joblib.load('feature_columns.pkl')
    print(f"Model loaded: {MODEL.__class__.__name__}")
    print(f"Features used: {FEATURE_COLUMNS}")
except FileNotFoundError:
    # Placeholder model if files are missing
    print("WARNING: Model files not found. Using Placeholder Model (Naive Rank Predictor).")
    class PlaceholderModel:
        def predict_proba(self, X):
            # FIXED: Access the 'rank_difference' column using its label (name)
            # instead of array indexing, as X is a DataFrame when scaled
            
            # X could be a DataFrame (if scaler is DummyScaler) or a NumPy array 
            # (if scaler performs to_numpy()). We use iloc[0] to access the first row 
            # if it's a DataFrame, which is the safest approach for the scaled input.
            if isinstance(X, pd.DataFrame):
                rank_diff = X['rank_difference'].iloc[0]
            else:
                # Fallback for array-like object if the scaler changed its type
                # Assumes 'rank_difference' is the first feature in the array
                rank_diff = X[0][0] 

            if rank_diff < 0:
                proba_A = 0.75
            elif rank_diff > 0:
                proba_A = 0.25
            else:
                proba_A = 0.5
            return np.array([[1 - proba_A, proba_A]])
    MODEL = PlaceholderModel()
    # Dummy scaler/features setup for execution
    class DummyScaler:
        def transform(self, X): return X
    SCALER = DummyScaler() 
    FEATURE_COLUMNS = ['rank_difference', 'point_difference', 'rolling_win_rate_difference', 'strength_index_difference', 'home_team_fifa_rank', 'away_team_fifa_rank', 'home_team_total_fifa_points', 'away_team_total_fifa_points']

def get_team_features(team_name):
    """Retrieves features for a given team from the simulated data."""
    return TEAM_2026_DATA.get(team_name, None)

def prepare_match_data(team_A_name, team_B_name, feature_cols, scaler):
    """Calculates the difference features (Team A - Team B) and scales the input."""
    team_A = get_team_features(team_A_name)
    team_B = get_team_features(team_B_name)
    
    if not team_A or not team_B:
        raise ValueError(f"Data not found for {team_A_name} or {team_B_name}.")

    features = {}
    features['rank_difference'] = team_A['rank'] - team_B['rank']
    features['point_difference'] = team_A['points'] - team_B['points']
    features['rolling_win_rate_difference'] = team_A['win_rate'] - team_B['win_rate']
    features['strength_index_difference'] = team_A['strength_index'] - team_B['strength_index']
    features['home_team_fifa_rank'] = team_A['rank']
    features['away_team_fifa_rank'] = team_B['rank']
    features['home_team_total_fifa_points'] = team_A['points']
    features['away_team_total_fifa_points'] = team_B['points']

    X_match = pd.DataFrame([features], columns=feature_cols)
    X_scaled = scaler.transform(X_match)
    return X_scaled

def predict_match(team_A, team_B, model, feature_cols, scaler):
    """Predicts the winner of a single match using two-way prediction."""
    
    # Predict P(A wins)
    X_match_A = prepare_match_data(team_A, team_B, feature_cols, scaler)
    proba_A_win = model.predict_proba(X_match_A)[0][1]

    # Predict P(B wins)
    X_match_B = prepare_match_data(team_B, team_A, feature_cols, scaler)
    proba_B_win = model.predict_proba(X_match_B)[0][1]

    # Determine winner based on higher probability
    if proba_A_win > proba_B_win:
        winner = team_A
        win_proba = proba_A_win
    elif proba_B_win > proba_A_win:
        winner = team_B
        win_proba = proba_B_win
    else:
        # Tie-breaker (use better rank)
        rank_A = get_team_features(team_A)['rank']
        rank_B = get_team_features(team_B)['rank']
        winner = team_A if rank_A < rank_B else team_B
        win_proba = proba_A_win

    return winner, win_proba, proba_A_win, proba_B_win

def simulate_round(match_list, model, feature_cols, scaler):
    """Simulates a list of matches and returns the winners."""
    winners = []
    print(f"\n--- Simulating Round ({len(match_list)} matches) ---")
    for team1, team2 in match_list:
        winner, proba, proba1, proba2 = predict_match(team1, team2, model, feature_cols, scaler)
        
        # Display the prediction clearly
        print(f"Match: {team1} vs {team2} -> Winner: {winner} (P({team1} win)={proba1:.2f}, P({team2} win)={proba2:.2f})")
        
        winners.append(winner)
    return winners

# --- 2. DETERMINE FINAL 48 TEAMS (Confirmed 28 + Remaining 20) ---

# All teams in the simulated data
ALL_SIMULATED_TEAMS = list(TEAM_2026_DATA.keys())

# Identify candidates for the remaining 20 slots
non_qualified_candidates = [
    team for team in ALL_SIMULATED_TEAMS 
    if team not in CONFIRMED_28
]

# Sort non-qualified candidates by rank (ascending: lower rank number is better)
REMAINING_20_CANDIDATES = sorted(
    non_qualified_candidates, 
    key=lambda team: TEAM_2026_DATA[team]['rank']
)

# Select the top 20 highest-ranked non-qualified teams
REMAINING_20 = REMAINING_20_CANDIDATES[:20]

# Final 48 Qualified Teams List (sorted by rank for R32 seeding)
ALL_TEAMS_48 = CONFIRMED_28 + REMAINING_20
ALL_TEAMS_SORTED = sorted(ALL_TEAMS_48, key=lambda x: TEAM_2026_DATA[x]['rank'])

print("\n--- Final 48 Qualified Teams (Sorted by Rank) ---")
for i, team in enumerate(ALL_TEAMS_SORTED[:24]):
    status = "Confirmed" if team in CONFIRMED_28 else "Predicted"
    print(f"Rank {i+1:02}: {team:<15} ({status})")
    
print("...")
for i, team in enumerate(ALL_TEAMS_SORTED[24:]):
    status = "Confirmed" if team in CONFIRMED_28 else "Predicted"
    print(f"Rank {25+i:02}: {team:<15} ({status})")
    
print("\n" + "="*50)

# --- 3. TOURNAMENT SIMULATION (KNOCKOUT ROUNDS) ---

print("\n\n#####################################################")
print("####### 2026 FIFA WORLD CUP PREDICTION #######")
print("#####################################################")

# The Round of 32 in the 48-team format features the winners of the Group Stage.
# For simplicity, we assume the top 32 teams by rank from the 48 qualified teams advance to the knockout stage.
R32_ADVANCED_TEAMS = ALL_TEAMS_SORTED[:32]
R32_MATCHES = []
# Pairing: 1v32, 2v31, ... 16v17
for i in range(16):
    R32_MATCHES.append((R32_ADVANCED_TEAMS[i], R32_ADVANCED_TEAMS[31 - i]))
    
print("\n" + "="*50)
print("Round of 32 Matchups (Simplified Bracket of Top 32 Ranked Teams)")
print("="*50)

# --- Round of 32 ---
r32_winners = simulate_round(R32_MATCHES, MODEL, FEATURE_COLUMNS, SCALER)


# --- Round of 16 ---
R16_MATCHES = []
# Pair consecutive winners: W1 vs W2, W3 vs W4, etc. (Assumes a structured bracket flow)
for i in range(0, len(r32_winners), 2):
    R16_MATCHES.append((r32_winners[i], r32_winners[i+1]))
    
r16_winners = simulate_round(R16_MATCHES, MODEL, FEATURE_COLUMNS, SCALER)


# --- Quarter-Finals (QF) ---
QF_MATCHES = []
for i in range(0, len(r16_winners), 2):
    QF_MATCHES.append((r16_winners[i], r16_winners[i+1]))
    
qf_winners = simulate_round(QF_MATCHES, MODEL, FEATURE_COLUMNS, SCALER)


# --- Semi-Finals (SF) ---
SF_MATCHES = []
for i in range(0, len(qf_winners), 2):
    SF_MATCHES.append((qf_winners[i], qf_winners[i+1]))

sf_winners = simulate_round(SF_MATCHES, MODEL, FEATURE_COLUMNS, SCALER)


# --- Final ---
FINALISTS = sf_winners 
CHAMPION, champion_proba, _, _ = predict_match(sf_winners[0], sf_winners[1], MODEL, FEATURE_COLUMNS, SCALER)


# --- 4. FINAL RESULTS ---
print("\n\n=====================================================")
print("============== 🏆 FINAL TOURNAMENT PREDICTION 🏆 ==============")
print("=====================================================")

print(f"\nPredicted Finalists:")
print(f"  - {FINALISTS[0]} vs. {FINALISTS[1]}")

print(f"\nPredicted 2026 World Cup Champion:")
print(f"  - {CHAMPION} (Prediction Confidence: {champion_proba*100:.2f}%)")
print("\n=====================================================")

print("\nDetailed breakdown of the predicted 48 teams and the tournament's simulated progression is available in the final file.")