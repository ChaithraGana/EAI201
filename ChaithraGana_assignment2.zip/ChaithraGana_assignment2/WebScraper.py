import pandas as pd
import requests
import time
import random
import os

TARGET_URL = 'https://en.wikipedia.org/wiki/List_of_FIFA_World_Cup_finals'
OUTPUT_FILE = 'fifa_final_match_data.csv'

# Define a consistent User-Agent
HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
}

def scrape_fifa_final_data(url, output_file):
    """
    Scrapes the historical FIFA World Cup final match data using a robust table-matching strategy.
    """
    print(f"Starting scrape from: {url}")
    
    # 1. Fetch HTML content using requests
    try:
        response = requests.get(url, headers=HEADERS, timeout=10)
        response.raise_for_status() 
        print("Successfully fetched HTML content.")
        time.sleep(random.uniform(1, 3)) 
    except requests.exceptions.RequestException as e:
        print(f"Error fetching URL: {e}")
        return

    # 2. Extract table data using pandas with a precise match
    try:
        # Use 'match' to find the table that contains the word 'Attendance'.
        tables = pd.read_html(response.text, match='Attendance')
        
        if not tables:
            print("FATAL ERROR: Could not find the main historical table matching 'Attendance'.")
            return

        df_raw = tables[0] 
        print(f"Successfully isolated the target table with {len(df_raw.columns)} columns.")
        
    except Exception as e:
        print(f"Error during table reading: {e}")
        return

    # 3. Data Cleaning and Preparation (Scraping Logic)

    # We select the first 6 columns: [0:Year, 1:Winners, 2:Score, 3:Runners-up, 4:Venue, 5:Location]
    required_cols = 6
    if len(df_raw.columns) < required_cols:
        print(f"\nFATAL ERROR: The selected table only has {len(df_raw.columns)} columns, expected at least {required_cols}.")
        print(f"Raw Column Names: {df_raw.columns.tolist()}")
        return

    # Select the first 6 columns
    df_clean = df_raw.iloc[:, :required_cols].copy()
        
    # Rename columns to match the scraped data order
    df_clean.columns = ['Year', 'Winner', 'Score', 'Runner_up', 'Venue', 'Host']
    
    # Filter out header rows that might be repeated
    df_clean = df_clean[df_clean['Year'] != 'Year'].reset_index(drop=True)
    
    # Clean up names by removing footnote references (e.g., '[1]', '[a]')
    for col in ['Winner', 'Runner_up', 'Venue', 'Host']:
        df_clean[col] = df_clean[col].astype(str).str.replace(r'\[.*\]', '', regex=True).str.strip()
    
    # Remove future/placeholder rows 
    df_clean = df_clean[df_clean['Host'] != 'TBD'].copy()

    # 4. Save the data with robust permission handling
    try:
        df_clean.to_csv(output_file, index=False, encoding='utf-8')
        print(f"\nData collection complete. **{len(df_clean)} records** saved to **{output_file}**")
    except PermissionError:
        # Fallback if the file is locked or permissions are denied
        fallback_path = os.path.join(os.path.expanduser('~'), 'fifa_final_match_data_FALLBACK.csv')
        df_clean.to_csv(fallback_path, index=False, encoding='utf-8')
        
        print("\nPERMISSION ERROR: The original file could not be saved.")
        print("   Action Required:Please ensure 'fifa_final_match_data.csv' is closed in all other programs.")
        print(f"  SUCCESS:As a temporary solution, the data was saved to your home directory at: {fallback_path}")

    # Printing the first few rows for verification
    print("\n Sample Scraped Data")
    print(df_clean.head())

#  EXECUTION 
if __name__ == "__main__":
    scrape_fifa_final_data(TARGET_URL, OUTPUT_FILE)