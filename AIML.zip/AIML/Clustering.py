# Step 1: Import libraries
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
import matplotlib.pyplot as plt
import seaborn as sns

# Step 2: Load data
df = pd.read_csv('Telco-Customer-Churn.csv')  # Change path if needed

# Part A: Preprocessing
# Drop customerID (not informative)
df = df.drop('customerID', axis=1)

# Encode categoricals
for col in df.select_dtypes(include=['object']).columns:
    if df[col].nunique() == 2:
        # Binary columns: Yes/No to 1/0
        df[col] = LabelEncoder().fit_transform(df[col])
    else:
        # Multi-category columns: One-hot encoding
        df = pd.get_dummies(df, columns=[col])

# Replace missing/blank strings with numerical nulls (if any exist)
df = df.replace(' ', np.nan)
df = df.dropna()  # Drop rows with missing data for simplicity

# Standardize numeric columns
scaler = StandardScaler()
X_scaled = scaler.fit_transform(df)

# Part B: PCA to 2 components and explained variance
pca = PCA(n_components=2)
X_pca = pca.fit_transform(X_scaled)

print("Explained variance by PCA components:", pca.explained_variance_ratio_.sum())

# Plot PCA results
plt.figure(figsize=(8,6))
plt.scatter(X_pca[:,0], X_pca[:,1], alpha=0.5)
plt.xlabel("PC1")
plt.ylabel("PC2")
plt.title("PCA 2D scatter plot")
plt.show()

# Part C: K-Means clustering

# Find optimal K using Elbow Method
sse = []
range_n = range(2, 11)
for k in range_n:
    km = KMeans(n_clusters=k, random_state=42)
    km.fit(X_pca)
    sse.append(km.inertia_)

plt.plot(range_n, sse)
plt.xlabel('K')
plt.ylabel('SSE (Inertia)')
plt.title('Elbow Plot for Optimal K')
plt.show()

# Find optimal K using Silhouette Score
sil = []
for k in range_n:
    km = KMeans(n_clusters=k, random_state=42)
    labels = km.fit_predict(X_pca)
    sil.append(silhouette_score(X_pca, labels))

plt.plot(range_n, sil)
plt.xlabel('K')
plt.ylabel('Silhouette Score')
plt.title('Silhouette Score for Different K')
plt.show()

optimal_k = range_n[np.argmax(sil)]
print("Optimal K selected (highest silhouette):", optimal_k)

# Apply KMeans with optimal K
kmeans = KMeans(n_clusters=optimal_k, random_state=42)
labels = kmeans.fit_predict(X_pca)

# Plot clusters
plt.figure(figsize=(8,6))
sns.scatterplot(x=X_pca[:,0], y=X_pca[:,1], hue=labels, palette='tab10', legend='full')
plt.title('K-Means Clusters in PCA Space')
plt.show()

# Part D (Bonus): Cluster analysis on original data
df['Cluster'] = labels
cluster_summary = df.groupby('Cluster').agg({
    'MonthlyCharges':'mean',
    'tenure':'mean',
    'Churn':'mean'  # If Churn exists
})
print("Cluster summary (charges, tenure, churn %):\n", cluster_summary)

# Interpret clusters (print the description for each segment)
for idx, row in cluster_summary.iterrows():
    print(f"Cluster {idx}: Avg MonthlyCharges={row['MonthlyCharges']:.2f}, Avg Tenure={row['tenure']:.2f}, Churn Rate={row['Churn']:.2f}")

# Deliverables:
# - All code above
# - Visualizations shown for PCA, elbow, silhouette, and clusters
# - Printed answers and interpretations
