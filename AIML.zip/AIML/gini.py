# Data from the table
data = [
    {"hours": 2, "label": 0},
    {"hours": 4, "label": 0},
    {"hours": 6, "label": 1},
    {"hours": 8, "label": 1},
    {"hours": 10, "label": 1},
]

def gini_impurity(labels):
    n = len(labels)
    if n == 0:
        return 0
    count_0 = sum(1 for l in labels if l == 0)
    count_1 = sum(1 for l in labels if l == 1)
    p0 = count_0 / n
    p1 = count_1 / n
    return 1 - (p0**2 + p1**2)

# Find best threshold to split on study hours
def find_best_split(data):
    # Sort by study hours
    data_sorted = sorted(data, key=lambda x: x["hours"])
    hours = [d["hours"] for d in data_sorted]
    labels = [d["label"] for d in data_sorted]
    best_gini = None
    best_split = None
    best_groups = None

    # Possible splits are between values
    for i in range(1, len(data)):
        threshold = (hours[i-1] + hours[i]) / 2
        left = [d["label"] for d in data if d["hours"] <= threshold]
        right = [d["label"] for d in data if d["hours"] > threshold]
        # Weighted Gini impurity
        gini_left = gini_impurity(left)
        gini_right = gini_impurity(right)
        n_left = len(left)
        n_right = len(right)
        weighted_gini = (n_left * gini_left + n_right * gini_right) / (n_left + n_right)
        print(f"Split at {threshold:.2f}: Left={left}, Right={right} | Gini={weighted_gini:.4f}")

        if best_gini is None or weighted_gini < best_gini:
            best_gini = weighted_gini
            best_split = threshold
            best_groups = (left, right)
    return best_split, best_gini, best_groups

# Main execution
split, gini, groups = find_best_split(data)
print(f"\nBest split at study hours <= {split}:")
print(f"Gini impurity: {gini:.4f}")

# Visualize final tree as text (since it's a simple 1-level split)
left_label = 0 if sum(groups[0])/len(groups[0]) < 0.5 else 1
right_label = 0 if sum(groups[1])/len(groups[1]) < 0.5 else 1
print("\nDecision Tree:")
print(f"If study hours <= {split:.1f}: Predict {left_label}")
print(f"If study hours > {split:.1f}: Predict {right_label}")
