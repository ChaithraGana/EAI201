# Install required libraries: pip install pandas numpy matplotlib seaborn scikit-learn

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# 1. Load the Titanic dataset
titanic = pd.read_csv("titanic.csv")  # Place titanic.csv in your project directory

# 2. Summarize missing values and data types
print("Missing values per column:\n", titanic.isnull().sum())
print("\nData types:\n", titanic.dtypes)

# 3. Visualize distributions of key features
plt.figure(figsize=(7,3))
sns.histplot(titanic['Age'].dropna(), bins=30, kde=True)
plt.title('Age Distribution')
plt.show()

sns.countplot(x='Sex', data=titanic)
plt.title('Sex Distribution')
plt.show()

sns.countplot(x='Pclass', data=titanic)
plt.title('Class Distribution')
plt.show()

plt.figure(figsize=(7,3))
sns.histplot(titanic['Fare'].dropna(), bins=40, kde=True)
plt.title('Fare Distribution')
plt.show()

sns.countplot(x='Embarked', data=titanic)
plt.title('Embarked Distribution')
plt.show()

# 4. Analyze relationships between features and survival
sns.barplot(x='Sex', y='Survived', data=titanic)
plt.title('Survival Rate by Sex')
plt.show()

sns.barplot(x='Pclass', y='Survived', data=titanic)
plt.title('Survival Rate by Class')
plt.show()

sns.barplot(x='Embarked', y='Survived', data=titanic)
plt.title('Survival Rate by Embarked')
plt.show()

# 5. Data Cleaning and Imputation
titanic['Age'].fillna(titanic['Age'].median(), inplace=True)
titanic['Embarked'].fillna(titanic['Embarked'].mode()[0], inplace=True)
titanic['Fare'].fillna(titanic['Fare'].median(), inplace=True)

# 6. Drop irrelevant columns
titanic = titanic.drop(['PassengerId','Ticket','Cabin'], axis=1)

# 7. Feature Engineering
# - FamilySize
titanic['FamilySize'] = titanic['SibSp'] + titanic['Parch'] + 1

# - Extract Title from Name
titanic['Title'] = titanic['Name'].apply(
    lambda name: name.split(',')[1].split('.')[0].strip()
)
# - Drop Name now that Title is extracted
titanic = titanic.drop('Name', axis=1)

# 8. Convert categorical features to numeric (one-hot encoding)
titanic = pd.get_dummies(titanic, columns=['Sex','Embarked','Title'], drop_first=True)

# 9. Prepare Data for Modeling
from sklearn.model_selection import train_test_split

X = titanic.drop('Survived', axis=1)
y = titanic['Survived']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

print("Training set shape:", X_train.shape)
print("Test set shape:", X_test.shape)

# Check data readiness
print("Any NA in training data: ", X_train.isnull().values.any())
print("Any NA in test data: ", X_test.isnull().values.any())