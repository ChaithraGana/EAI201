# Lab – Linear Regression on the Boston Housing Dataset
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score, mean_squared_error

# Task A1: Data Loading and Exploration
data_url = "http://lib.stat.cmu.edu/datasets/boston"
raw_df = pd.read_csv(data_url, sep="\s+", skiprows=22, header=None)

# Preprocess: Stack two rows together to get one sample
X = np.hstack([raw_df.values[::2, :], raw_df.values[1::2, :2]])
y = raw_df.values[1::2, 2]
feature_names = ["CRIM","ZN","INDUS","CHAS","NOX","RM","AGE","DIS","RAD","TAX","PTRATIO","B","LSTAT"]
df = pd.DataFrame(X, columns=feature_names)
df['PRICE'] = y

# Examine structure
print("Samples:", df.shape[0])
print("Features:", len(feature_names))
print("Price (min, max, mean):", df['PRICE'].min(), df['PRICE'].max(), df['PRICE'].mean())

# Task A2: Exploratory Data Analysis
plt.hist(df['PRICE'], bins=30, edgecolor='black')
plt.xlabel('Price')
plt.ylabel('Frequency')
plt.title('Histogram of House Prices')
plt.show()

corr_matrix = df.corr()
plt.figure(figsize=(12,10))
sns.heatmap(corr_matrix, annot=True, cmap='coolwarm')
plt.title('Correlation Matrix')
plt.show()

price_corr = corr_matrix['PRICE'].drop('PRICE').sort_values(ascending=False)
best_feature = price_corr.index[0]
print("Feature with strongest positive correlation:", best_feature)
print("Correlation value:", price_corr[0])

plt.scatter(df[best_feature], df['PRICE'])
plt.xlabel(best_feature)
plt.ylabel('Price')
plt.title(f'Price vs {best_feature}')
plt.show()

skewness = df['PRICE'].skew()
if abs(skewness) < 0.5:
    print('Price distribution is approximately normal.')
else:
    print(f'Price distribution is skewed (skewness={skewness:.2f}).')

# Task A3: Model Building and Evaluation
X = df[feature_names]
y = df['PRICE']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
model = LinearRegression()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)

r2 = r2_score(y_test, y_pred)
rmse = np.sqrt(mean_squared_error(y_test, y_pred))
print(f'R² Score: {r2:.3f}')
print(f'RMSE: {rmse:.3f}')

plt.scatter(y_test, y_pred, alpha=0.6)
plt.plot([min(y_test), max(y_test)], [min(y_test), max(y_test)], 'r--', linewidth=2)
plt.xlabel('Actual Prices')
plt.ylabel('Predicted Prices')
plt.title('Actual vs Predicted Prices')
plt.show()

print("Model's R² is", r2, "- this is a common result for basic linear regression on this dataset.")
print("Check the plot for systematic errors; sometimes performance varies for low/high price ranges.")
