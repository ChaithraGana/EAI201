
import numpy as np
import pandas as pd
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix
import matplotlib.pyplot as plt

# Task B1: Data Loading and Preparation
iris = load_iris()
X = iris['data']
y = iris['target']
target_names = iris['target_names']

# Convert to DataFrame for easy handling
df = pd.DataFrame(X, columns=iris['feature_names'])
df['class'] = y

# Convert to binary classification: Setosa (1) vs Others (0)
df['binary_class'] = (df['class'] == 0).astype(int)  # Setosa is target 0
print("Binary class value counts:")
print(df['binary_class'].value_counts())

# Check class balance
setosa_count = df['binary_class'].sum()
non_setosa_count = len(df) - setosa_count
print(f"Samples in Setosa: {setosa_count}")
print(f"Samples in Non-Setosa: {non_setosa_count}")

# Task B2: Exploratory Data Analysis

# Bar plot of class distribution
plt.figure()
df['binary_class'].value_counts().plot(kind='bar', title='Class Distribution (Setosa vs Non-Setosa)')
plt.xlabel('Class (1=Setosa, 0=Non-Setosa)')
plt.ylabel('Count')
plt.show()

# Scatter plot: petal length vs petal width, colored by class
plt.figure()
colors = {1: 'blue', 0: 'red'}
for cl in [0, 1]:
    subset = df[df['binary_class']==cl]
    plt.scatter(subset['petal length (cm)'], subset['petal width (cm)'],
                color=colors[cl], label=f"{'Setosa' if cl==1 else 'Non-Setosa'}")
plt.title('Petal Length vs Petal Width')
plt.xlabel('Petal Length (cm)')
plt.ylabel('Petal Width (cm)')
plt.legend()
plt.show()

# Compare feature means between Setosa & Non-Setosa
print("\nMean feature values by class:")
means = df.groupby('binary_class').mean(numeric_only=True)
print(means)

# Most different features
diff = means.loc[1] - means.loc[0]
print("\nFeature difference (Setosa - Non-Setosa):")
print(diff)

# Task B3: Model Building and Evaluation

# Split into training (70%) and testing (30%)
X = df[iris['feature_names']]
y = df['binary_class']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42, stratify=y)

# Train Logistic Regression model
model = LogisticRegression()
model.fit(X_train, y_train)

# Make predictions and calculate accuracy
y_pred = model.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)
print(f"\nModel accuracy: {accuracy:.2f}")

# Create confusion matrix
cm = confusion_matrix(y_test, y_pred)
print("Confusion Matrix:")
print(cm)

# Examine feature coefficients (importance)
coeffs = model.coef_[0]
features = iris['feature_names']
coef_df = pd.DataFrame({'Feature': features, 'Coefficient': coeffs, 'Absolute Coefficient': np.abs(coeffs)})
print("\nFeature coefficients:")
print(coef_df)

# Feature with largest absolute coefficient
max_feature = coef_df.loc[coef_df['Absolute Coefficient'].idxmax()]
print(f"\nFeature with largest absolute coefficient: {max_feature['Feature']}")
print("This feature is most influential in distinguishing Setosa from Non-Setosa.")

# Confusion matrix interpretation
print("\nConfusion Matrix (rows=true, cols=predicted):")
print(f"True Setosa predicted as Setosa: {cm[1,1]}")
print(f"True Setosa predicted as Non-Setosa: {cm[1,0]}")
print(f"True Non-Setosa predicted as Non-Setosa: {cm[0,0]}")
print(f"True Non-Setosa predicted as Setosa: {cm[0,1]}")
